<?php
/**
 * Partial: Page - right section.
 *
 * @package    Edwiser Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<div>
	<div class="eb_settings_pop_btn_wrap">
	</div>
</div>
